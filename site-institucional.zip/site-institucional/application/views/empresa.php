<?php $this->load->view('commons/header') ?>
<div class="container">
	<div class="page-header">
		<h1>A Empresa</h1>
	</div>
	<p class="lead">Você está criando a página com as informações da empresa</p>
	<p>
		Essa é uma página simples, contendo cabeçalho e rodapé, e o conteúdo sendo um título e 2 parágrafos.
	</p>
</div>
<?php $this->load->view('commons/footer') ?>
